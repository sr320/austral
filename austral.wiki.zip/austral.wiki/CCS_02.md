#Core Computational Skills - Git and IPython

**Objective:** Set-up computing environments for bioinformatics analysis and learn basic unix commands. Many of the latter educational material has been adapted from Software Carpentry.

---

*credit*:    
[![sc](http://eagle.fish.washington.edu/cnidarian/skitch/Files_and_Directories_1A575F8C.png)](http://software-carpentry.org/)   
Copyright (c) Software Carpentry      
see also    
<http://sophieclayton.github.io/2015-01-15-uw/novice/git/index.html>

#Version Control with Git
Version control is the lab notebook of the digital world: it's what professionals use to keep track of what they've done and to collaborate with other people. Every large software development project relies on it, and most programmers use it for their small jobs as well. And it isn't just for software: books, papers, small data sets, and anything that changes over time or needs to be shared can and should be stored in a version control system.

1. [Introducing Version Control](http://sophieclayton.github.io/2015-01-15-uw/novice/git/00-intro.html)
2. [A Better Kind of Backup](http://sophieclayton.github.io/2015-01-15-uw/novice/git/01-backup.html)
3. [Collaborating](http://sophieclayton.github.io/2015-01-15-uw/novice/git/02-collab.html)

----


#IPython
  
* [IPython webpage](http://ipython.org/)
* [Rich System Display](http://nbviewer.ipython.org/github/ipython/ipython/blob/1.x/examples/notebooks/Part%205%20-%20Rich%20Display%20System.ipynb) - some different ways to display in IPython
* [nbviewer](http://nbviewer.ipython.org)-service for viewing notebooks
* [SageMath Cloud](https://cloud.sagemath.com/)-platform that offers IPython notebooks

---

#Blast 

* [Installing Blast](http://nbviewer.ipython.org/github/sr320/austral/blob/master/modules/01-Piura-Annotation/01-Local_BLAST.ipynb)
  