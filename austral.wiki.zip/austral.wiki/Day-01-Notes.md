#Day 01

#Lecture

Here is a link to the slides-
https://dl.dropboxusercontent.com/u/115356/austral/01_Introduction_f.pdf

### First, we have learned about the schedule of this course.
![](http://s18.postimg.org/6uzhugnsp/Captura_de_pantalla_2015_01_20_a_la_s_17_33_58.png)
Picture of membrane
![pic](http://eagle.fish.washington.edu/cnidarian/skitch/https___dl_dropboxusercontent_com_u_115356_austral_01_Introduction_f_pdf_1A6EF2DE.png)


#Computer lab

* We had to convert SFF file to Fastq in Iplant.
* We had check the quality of reads from massive sequencing data and trim them to improve their quality, using Apps from iPlant.


* [Bash code examples from Roberts Lab](https://github.com/sr320/LabDocs/blob/master/code/bash.md)



Thought this might be useful. Here are a few code words for Terminal, iPython, etc.

* Ls: lists directory content     
* Cd: goes to the specified directory
* Pwd: displays path      
* Cd..: goes up one directory level      
* Mkdir: creates a directory       
* Nano: opens a text editor        
* Rm: removes or deletes a directory or file    
* WC: word count, with the modifier -L it counts the lines of text    
* Cat: concatenate    
* Sort: sorts and selects    
* Head: shows the first lines of a text file    
* Tail: shows the last lines of a text file    
* ./: runs a program    



####SQLSHARE

* [SQLSHARE code examples from Roberts Lab](https://github.com/sr320/LabDocs/blob/master/code/sqlshare.md)
* [Video of Recent Talk on SQLShare](https://panopto.uw.edu/Panopto/Content/Sessions/35bb9478-5c64-41f2-b8ec-3c718fdd0c6c/ca8719d0-632c-41f8-90d7-6b1218cd8074-25d364f2-4c8f-490d-8a16-a66198576835.mp4?invocationId=3f7958eb-8da1-e411-8906-06c17400005a) - [source](https://github.com/sr320/escience-talk-sqlshare-2015)
