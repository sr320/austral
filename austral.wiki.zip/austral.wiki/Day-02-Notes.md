# Lecture
Slides - https://dl.dropboxusercontent.com/u/115356/austral/02_Environment_f.pdf


