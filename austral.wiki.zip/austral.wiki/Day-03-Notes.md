We have been talking about EPIGENETICS 


Video materials 
- "The ghost in your genes" https://www.youtube.com/watch?v=fMxgkSgZoJs&noredirect=1
- "A tale of two mice" http://www.pbs.org/wgbh/nova/body/epigenetic-mice.html

In the computer lab with have been analizing Differential Expression Genes (DEGs analysis) using data from sea star (Phel) and pacific oyster (Cgigas)


