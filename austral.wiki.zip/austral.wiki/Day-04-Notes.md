# 1. Diseases in marine species

# 2. Open Science

### The main web-resources to conduct bioinformatic analyses and to collaborate:

![](http://s21.postimg.org/4kn5tjm0n/open_Science.png)


