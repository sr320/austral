Playlist of Youtube videos.

_click on screenshot and new window will open_


[![pl](http://eagle.fish.washington.edu/cnidarian/skitch/austral_-_YouTube_1A571F35.png)](https://www.youtube.com/playlist?list=PLLDVqNxOKWsRYKBHZpYLLFMqdMwrG6T7l)

---

#Epigenetics Videos
How methylation silences DNA
http://www.youtube.com/watch?v=Tj_6DcUTRnM


X-chromosome inactivation (great illustration of epigenetics)
http://www.youtube.com/watch?v=mHak9EZjySs

Chromatin, histones, acetylation animation
https://www.youtube.com/watch?v=eYrQ0EhVCYA

Epigenetics animations (commercial company)
http://www.youtube.com/watch?v=N2LbVMcQbLk

Lick your rats
http://learn.genetics.utah.edu/content/epigenetics/rats/

Ghost in your genes
http://youtu.be/toRIkRa1fYU

A tale of two mice
http://goo.gl/DpGkQh