<img src="http://eagle.fish.washington.edu/cnidarian/skitch/Description_-_Austral_Summer_Institute_XV_1A56F09F.png" alt="Description_-_Austral_Summer_Institute_XV_1A56F09F.png"/>


## Physiological response of marine organisms to environmental change from a genomic perspective

**19-23 January 2015**

---


#Schedule

Day          | Physiology        | CCS           | Module
------------ | -------------     | ------------  |------------
Monday       | [Cell and Membranes](https://dl.dropboxusercontent.com/u/115356/austral/01_Introduction_f.pdf)| [Shell](https://github.com/sr320/austral/wiki/CCS_01)         | [Annotation](http://nbviewer.ipython.org/github/sr320/austral/blob/master/modules/01-Piura-Annotation/00_Piura.ipynb)  
Tuesday      | [Environmental Stress](https://dl.dropboxusercontent.com/u/115356/austral/02_Environment_f.pdf)| [Shell](https://github.com/sr320/austral/wiki/CCS_01)         | [Annotation](http://nbviewer.ipython.org/github/sr320/austral/blob/master/modules/01-Piura-Annotation/00_Piura.ipynb)  
Wednesday    | Epigenetics [General](https://dl.dropboxusercontent.com/u/115356/austral/Epigenetics_general.pdf) &[Plasticity](https://dl.dropboxusercontent.com/u/115356/austral/Epigenetics_plasticity.pdf)      | [Git & IPython](https://github.com/sr320/austral/wiki/CCS_02) | [RNA-Seq](https://github.com/sr320/ASI-rna-seq/blob/master/notebook/rna-seq_cgigas.md)
Thursday     | [Disease](/Users/sr320/Dropbox/Public/austral/Host_Response.pdf) & [Open Science](https://dl.dropboxusercontent.com/u/115356/austral/Open_Science.pdf)       | TBD           | [SNP](http://nbviewer.ipython.org/github/sr320/austral/blob/master/modules/04-Chile-SNP/00-Com-SNPs.ipynb)
Friday       | Presentations | TBD           | Lab Tour

---
_Instructor_:      
Steven Roberts     
robertslab.info     
sr320@uw.edu     
@sr320

_Description_   
Marine environments are continually changing in response to both natural processes and human activities, both having direct physiological impacts on marine organisms. This course will explore the surprising similarities and unique differences in the physiological response of diverse organisms. The main focus will be on functional responses to system stressors; however, the course will also explore how new discoveries in epigenetics is providing insight into phenotypic plasticity and evolutionary implications. A core component of this course will be hands on tutorials on examining high-throughput sequencing data. Specifically, transcriptome (RNA-seq) data from experiments where marine organisms are exposed to environmental change will be analyzed. Bioinformatic instruction will include modules on gene annotation, differential gene expression, and variant detection. There will be an emphasis on open science practices including the use of electronic lab notebooks. 


This is a five day course with AM lectures and hands-on bioinformatics modules in the afternoon. The learning objectives of this course include    
**1) Understanding of fundamental physiological processes    
2) Acquisition of core computing skills    
3) Hands-on experience with genomic datasets**

*Bonus Goal*    
Products:   
1) Characterization and Annotation of _Piura_ transcriptomes    
2) Temperature influence on oyster DNA methylation and gene expression in oysters (_Crassostrea gigas_)  
3) Intragenic SNP variation between _Piura_ and _Concholepas_ 

---

#Prerequisites
Before course begins, students should obtain accounts for the following services (if not already signed up for). Students will need access to a computer.

* [GitHub](https://github.com); Clients [Mac](https://mac.github.com) - [Windows](https://windows.github.com)
* [iPlant](http://www.iplantcollaborative.org)
* [SQLShare](https://sqlshare.escience.washington.edu) _Google Account needed_
* [SageMath Cloud](https://cloud.sagemath.com) _can wait for invite_


Please review content below

* [Markdown](https://help.github.com/articles/markdown-basics/)



_Optional_     
Below are recommended software / services that I believe are useful and we will cover in come degree during the course.

* [IPython](http://ipython.org)
* [R](http://www.r-project.org)
* [IGV](http://www.broadinstitute.org/igv/) (registration required)
* [TextWranger (Mac)](http://www.barebones.com/products/textwrangler/)
* [Galaxy](https://usegalaxy.org)