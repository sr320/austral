[Prerequisites](https://github.com/sr320/austral/wiki#prerequisites) (Links to Cloud Services used)   

[Quizzes](https://github.com/sr320/austral/labels/Class%20Question)

##Class Notes
[Day 01 Notes](https://github.com/sr320/austral/wiki/Day-01-Notes)     
[Day 02 Notes](https://github.com/sr320/austral/wiki/Day-02-Notes)     
[Day 03 Notes](https://github.com/sr320/austral/wiki/Day-03-Notes)     
[Day 04 Notes](https://github.com/sr320/austral/wiki/Day-04-Notes)     



##Quick Links
[Blast Output Complete](https://raw.githubusercontent.com/sr320/austral/master/modules/data/Piura_v1_uniprot_sprot.tab)

[SQLShare output -GOSlim](https://raw.githubusercontent.com/sr320/austral/master/modules/data/Piura_v1_GOslim.tab)